def main():
    while True:
        try:
            expression = input("Enter an expression (type 'q' to quit): ")
            if expression.lower() == 'q':
                break

            result = eval(expression)
            print("Result:", result)

        except Exception as e:
            print("Error:", e)


if __name__ == "__main__":
    main()
